package evoSim;



public class Globals {
	double radius = 50.00; 
	double angle = 60.00;
	protected int hexcountx = 7; //38 for full screen 7
	protected int hexcounty = 5; //20 for full screen 5
	double vertspace = radius * Math.sin(Math.toRadians(60.0));

}
