package evoSim;

public enum TreeChildPos {left,mid,right}
